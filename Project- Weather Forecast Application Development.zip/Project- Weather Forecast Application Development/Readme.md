# Weather Forecast Application

## **Overview**
This Weather Forecast Application retrieves real-time weather data using **OpenWeatherMap API** and displays it in a **user-friendly interface**. Users can:
- Search weather forecasts **by city name**.
- Get weather details for their **current location**.
- View **5-day extended weather forecast**.

This application is developed using:
- **HTML**
- **CSS (Tailwind CSS)**
- **JavaScript**
- **OpenWeatherMap API**

---

## **Features**
✅ Search weather forecasts by **city name**  
✅ Fetch weather data for **current location** (using geolocation)  
✅ Display **current weather conditions** (temperature, wind speed, humidity)  
✅ Show a **5-day forecast** with weather icons and details  
✅ **Responsive design** for desktops, tablets, and mobile devices  
✅ **Error handling** for invalid inputs and API failures  
✅ **Local storage** to store recent searched cities  

---

## **Project Structure**