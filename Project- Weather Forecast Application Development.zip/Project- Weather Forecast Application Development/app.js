const apiKey = "29a62dde57b10c4486cc496490eb25b4"; // Your OpenWeatherMap API Key
const cityInput = document.querySelector(".city-input");
const searchBtn = document.querySelector(".search-btn");
const locationBtn = document.querySelector(".location-btn");
const weatherInfo = document.querySelector(".weather-data");

// Event listener for city search
searchBtn.addEventListener("click", async () => {
    const city = cityInput.value.trim();
    if (!city) {
        alert("Please enter a city name.");
        return;
    }
    await fetchWeather(city);
});

// Event listener for current location search
locationBtn.addEventListener("click", async () => {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(async position => {
            const lat = position.coords.latitude;
            const lon = position.coords.longitude;
            await fetchWeatherByCoordinates(lat, lon);
        }, () => {
            alert("Unable to fetch location.");
        });
    } else {
        alert("Geolocation is not supported.");
    }
});

// Fetch weather data by city name
async function fetchWeather(city) {
    const url = `https://api.openweathermap.org/data/2.5/forecast?q=${city}&appid=${apiKey}&units=metric`;
    
    try {
        weatherInfo.innerHTML = "Loading...";
        const response = await fetch(url);
        if (!response.ok) throw new Error("City not found");

        const data = await response.json();
        displayWeatherData(data);
    } catch (error) {
        weatherInfo.innerHTML = `<p class="text-red-500">${error.message}</p>`;
    }
}

// Fetch weather data using geolocation coordinates
async function fetchWeatherByCoordinates(lat, lon) {
    const url = `https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`;
    
    try {
        weatherInfo.innerHTML = "Loading...";
        const response = await fetch(url);
        if (!response.ok) throw new Error("Location not found");

        const data = await response.json();
        displayWeatherData(data);
    } catch (error) {
        weatherInfo.innerHTML = `<p class="text-red-500">${error.message}</p>`;
    }
}

// Display weather data dynamically
function displayWeatherData(data) {
    const cityName = data.city.name;
    const country = data.city.country;
    const currentDate = new Date(data.list[0].dt * 1000).toLocaleDateString();
    const temperature = data.list[0].main.temp;
    const wind = data.list[0].wind.speed;
    const humidity = data.list[0].main.humidity;
    const weatherIcon = `https://openweathermap.org/img/wn/${data.list[0].weather[0].icon}.png`;
    const weatherCondition = data.list[0].weather[0].description;

    const weatherHtml = `
        <div class="current-weather">
            <div class="details">
                <h2>${cityName}, ${country} (${currentDate})</h2>
                <h4>Temperature: ${temperature}°C</h4>
                <h4>Wind: ${wind} km/h</h4>
                <h4>Humidity: ${humidity}%</h4>
            </div>
            <div class="icon">
                <img src="${weatherIcon}" alt="Weather Icon">
                <h4>${weatherCondition}</h4>
            </div>
        </div>
        <div class="days-forecast">
            <h2>5-Day Forecast</h2>
            <ul class="weather-cards">
                ${data.list.filter((_, index) => index % 8 === 0).map(day => `
                    <li class="card">
                        <h3>${new Date(day.dt * 1000).toLocaleDateString()}</h3>
                        <img src="https://openweathermap.org/img/wn/${day.weather[0].icon}.png" alt="Weather Icon">
                        <h4>Temp: ${day.main.temp}°C</h4>
                        <h4>Wind: ${day.wind.speed} km/h</h4>
                        <h4>Humidity: ${day.main.humidity}%</h4>
                    </li>
                `).join("")}
            </ul>
        </div>
    `;
    weatherInfo.innerHTML = weatherHtml;
}
